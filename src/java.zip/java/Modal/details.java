/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Modal;

/**
 *
 * @author User
 */
import com.jaunt.Element;
import java.util.List;

/**
 *
 * @author Lenovo1
 */
public class details {
    Element ahmedabadmirror;
    Element ahmedabadmirror2;
    Element ahmedabadmirror3;
    Element theindianexpress;
    Element theindianexpress2;
    Element theindianexpress3;
    List<String> ahmurl;
    List<String> indurl;

    public Element getAhmedabadmirror() {
        return ahmedabadmirror;
    }   
    public Element getAhmedabadmirror2() {
        return ahmedabadmirror2;
    }
    public Element getAhmedabadmirror3() {
        return ahmedabadmirror3;
    }

    public void setAhmedabadmirror(Element ahmedabadmirror) {
        this.ahmedabadmirror = ahmedabadmirror;
    }
    public void setAhmedabadmirror2(Element ahmedabadmirror2) {
        this.ahmedabadmirror2 = ahmedabadmirror2;
    }
    public void setAhmedabadmirror3(Element ahmedabadmirror3) {
        this.ahmedabadmirror3 = ahmedabadmirror3;
    }

    public Element getTheindianexpress() {
        return theindianexpress;
    }
    
    public Element getTheindianexpress2() {
        return theindianexpress2;
    }    
    public Element getTheindianexpress3() {
        return theindianexpress3;
    } 

    public void setTheindianexpress(Element theindianexpress) {
        this.theindianexpress = theindianexpress;
    }
       
    public void setTheindianexpress2(Element theindianexpress2) {
        this.theindianexpress2 = theindianexpress2;
    }   
    public void setTheindianexpress3(Element theindianexpress3) {
        this.theindianexpress3 = theindianexpress3;
    }
    

    public List<String> getAhmurl() {
        return ahmurl;
    }

    public void setAhmurl(List<String> ahmurl) {
        this.ahmurl = ahmurl;
    }
   
    
    public List<String> getIndurl() {
        return indurl;
    }

    public void setindurl(List<String> indurl) {
        this.indurl = indurl;
    }
    
    
}

